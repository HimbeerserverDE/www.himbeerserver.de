# Password Generator
This page generates a few passwords on the server and displays them to the user.
The code can be found [on GitHub](https://github.com/HimbeerserverDE/www.himbeerserver.de/blob/main/himbeerserver/usr/lib/cgi-bin/password_generator.lua).
## 32 Letters, digits, punctuation characters
${strongest1}
${strongest2}
${strongest3}
${strongest4}
${strongest5}
## 32 Letters, digits
${strong1}
${strong2}
${strong3}
${strong4}
${strong5}
## 32 Letters
${medium1}
${medium2}
${medium3}
${medium4}
${medium5}
## 16 Letters, digits
${weak1}
${weak2}
${weak3}
${weak4}
${weak5}

[Return to Index Page](/)
