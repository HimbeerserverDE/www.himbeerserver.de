let pages = {
	"Main Page": "/",
	"Projects": "/projects",
	"Web apps": "/apps",
	"Guides": "/guides",
	"Blog": "/blog",
	"Contact": "/contact",
};

function sidebar_open() {
	let container = document.getElementById("container");
	let bar = document.getElementById("sidebar");
	bar.style.opacity = 1;

	if (screen.width < 500) {
		bar.style.width = "100%";
		container.style.width = 0;
	} else {
		bar.style.width = "20%";
		container.style.left = "20%";
		container.style.width = "calc(80% - 4em)";
	}
}

function sidebar_close() {
	let container = document.getElementById("container");
	let bar = document.getElementById("sidebar");

	bar.style.opacity = 0;
	bar.style.width = 0;
	container.style.left = 0;
	container.style.width = "calc(100% - 4em)";
}

function sidebar_rd(path) {
	document.location.href = path;
}

function account_info() {
	document.location.href = "/cgi-bin/account/redirect.lua";
}

let i = 1;
for (let k in pages) {
	let sidebar = document.getElementById("sidebar");
	let div = document.createElement("div");

	div.className = "sb_btn";
	div.style.top = 5 + i*12.5 + "%";
	div.innerText = k;

	div.addEventListener("click", _ => {
		sidebar_rd(pages[k]);
	});

	sidebar.appendChild(div);
	i++;
}
